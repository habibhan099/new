import { Link } from "react-router-dom";
import React from "react";

function DeliveryLogin() {
  return (
    <div>
      <h1>Delivery Person Login</h1>

      <form>
        <div>
          <label>Phone Number</label>
          <br />
          <input
            type="tel"
            placeholder="Enter phone number"
          />
        </div>

        <br />

        <div>
          <label>Password</label>
          <br />
          <input
            type="password"
            placeholder="Enter password"
          />
        </div>

        <br />

        <button type="submit">Login</button>
      
        <nav className="form-links" aria-label="Related pages">
          <Link to="/delivery-registration">Create delivery person account</Link>
          <Link to="/assignment">View delivery assignments</Link>
          <Link to="/customer-login">Customer login</Link>
          <Link to="/">Home</Link>
        </nav>
      </form>
    </div>
  );
}

export default DeliveryLogin;