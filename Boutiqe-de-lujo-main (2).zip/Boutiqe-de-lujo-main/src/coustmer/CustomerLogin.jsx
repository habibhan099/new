import React from "react";
import { Link } from "react-router-dom";

function CustomerLogin() {
  return (
    <div>
      <h1>Customer Login</h1>

      <form>
        <div>
          <label>Email</label>
          <br />
          <input
            type="email"
            placeholder="Enter your email"
          />
        </div>

        <br />

        <div>
          <label>Password</label>
          <br />
          <input
            type="password"
            placeholder="Enter your password"
          />
        </div>

        <br />

        <div>
          <input type="checkbox" />
          <label> Remember me</label>
        </div>

        <br />

        <button type="submit">Login</button>
      
        <nav className="form-links" aria-label="Related pages">
          <Link to="/product-search">Browse products</Link>
          <Link to="/signup">Create an account</Link>
          <Link to="/admin-login">Admin login</Link>
          <Link to="/delivery-login">Delivery person login</Link>
          <Link to="/">Home</Link>
        </nav>
      </form>

      <p>
        Don't have an account? <Link to="/signup">Register</Link>
      </p>
    </div>
  );
}

export default CustomerLogin;