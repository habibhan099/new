import { Link } from "react-router-dom";
import React from "react";

function AdminLogin() {
  return (
    <div>
      <h1>Admin Login</h1>

      <form>
        <div>
          <label>Email</label>
          <br />
          <input
            type="email"
            placeholder="Enter admin email"
          />
        </div>

        <br />

        <div>
          <label>Password</label>
          <br />
          <input
            type="password"
            placeholder="Enter password"
          />
        </div>

        <br />

        <button type="submit">Login</button>
      
        <nav className="form-links" aria-label="Related pages">
          <Link to="/admin-dashboard">Open admin dashboard</Link>
          <Link to="/customer-login">Customer login</Link>
          <Link to="/delivery-login">Delivery person login</Link>
          <Link to="/">Home</Link>
        </nav>
      </form>
    </div>
  );
}

export default AdminLogin;