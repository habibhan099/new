import React from "react";
import { Link } from "react-router-dom";

function AdminDashboard() {
  return (
    <div>
      <h1>Admin Dashboard</h1>

      <p>Welcome to the Admin Panel</p>

      <hr />

      <div>
        <h3>Total Products</h3>
        <h2>120</h2>
      </div>

      <div>
        <h3>Total Customers</h3>
        <h2>85</h2>
      </div>

      <div>
        <h3>Total Orders</h3>
        <h2>45</h2>
      </div>

      <div>
        <h3>Delivery Persons</h3>
        <h2>12</h2>
      </div>

      <hr />

      <h2>Admin Menu</h2>

      <Link to="/products">Products</Link>
      <Link to="/categories">Categories</Link>
      <Link to="/orders">Orders</Link>
      <Link to="/customers">Customers</Link>
      <Link to="/deliveries">Delivery Persons</Link>

    </div>
  );
}

export default AdminDashboard;